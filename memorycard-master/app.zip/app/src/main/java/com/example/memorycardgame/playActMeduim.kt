package com.example.memorycardgame

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class playActMeduim : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_play_act_meduim)
    }
}