package com.example.memorycardgame

class Level(val level: String)